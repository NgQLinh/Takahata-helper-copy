module.exports=[94451,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_workspace_user_worker_page_actions_0typxwr.js.map