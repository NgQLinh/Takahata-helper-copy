module.exports=[714076,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_workspace_admin_kpi-reports_page_actions_0-vrz-b.js.map