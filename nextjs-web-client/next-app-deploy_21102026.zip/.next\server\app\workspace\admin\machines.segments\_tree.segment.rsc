:HL["/_next/static/chunks/0fxi_h-xzasxo.css","style"]
:HL["/_next/static/chunks/0ovo7w5cuyfip.css","style"]
:HL["/_next/static/chunks/1j3wya62tsrml.css","style"]
:HC["/",""]
:HL["/_next/static/chunks/26t8g8v9_op1h.css","style"]
0:{"tree":{"name":"","param":null,"prefetchHints":16,"slots":{"children":{"name":"workspace","param":null,"prefetchHints":0,"slots":{"children":{"name":"admin","param":null,"prefetchHints":0,"slots":{"children":{"name":"machines","param":null,"prefetchHints":0,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":0,"slots":null}}}}}}}}},"staleTime":300,"buildId":"tY43c_ob_NXNTf-d4Hi-_"}
