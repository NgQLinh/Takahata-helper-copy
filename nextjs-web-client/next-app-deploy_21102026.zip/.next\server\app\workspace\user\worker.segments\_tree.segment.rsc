:HL["/_next/static/chunks/0fxi_h-xzasxo.css","style"]
:HL["/_next/static/chunks/0ovo7w5cuyfip.css","style"]
:HL["/_next/static/chunks/1j3wya62tsrml.css","style"]
:HC["/",""]
:HL["/_next/static/chunks/0z6i6k2cdyxxj.css","style"]
0:{"tree":{"name":"","param":null,"prefetchHints":16,"slots":{"children":{"name":"workspace","param":null,"prefetchHints":0,"slots":{"children":{"name":"user","param":null,"prefetchHints":0,"slots":{"children":{"name":"worker","param":null,"prefetchHints":0,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":0,"slots":null}}}}}}}}},"staleTime":300,"buildId":"tY43c_ob_NXNTf-d4Hi-_"}
