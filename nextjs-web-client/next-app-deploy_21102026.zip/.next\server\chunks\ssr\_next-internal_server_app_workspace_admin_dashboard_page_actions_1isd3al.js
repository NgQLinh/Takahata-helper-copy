module.exports=[195625,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_workspace_admin_dashboard_page_actions_1isd3al.js.map