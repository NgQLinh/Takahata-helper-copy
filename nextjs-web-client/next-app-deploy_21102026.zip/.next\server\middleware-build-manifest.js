globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/tY43c_ob_NXNTf-d4Hi-_/_buildManifest.js",
    "static/tY43c_ob_NXNTf-d4Hi-_/_ssgManifest.js",
    "static/tY43c_ob_NXNTf-d4Hi-_/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/046rkacd53sxw.js",
    "static/chunks/3u1yqrswiftwe.js",
    "static/chunks/2ejk_26znfoeu.js",
    "static/chunks/06j3juy1u5a-6.js",
    "static/chunks/2-53m74dqkhnw.js",
    "static/chunks/turbopack-1145z3tbgoqu-.js"
  ]
};
