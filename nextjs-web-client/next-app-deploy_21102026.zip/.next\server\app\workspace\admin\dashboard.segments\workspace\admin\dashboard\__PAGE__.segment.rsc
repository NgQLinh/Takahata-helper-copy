1:"$Sreact.fragment"
2:I[474205,["/_next/static/chunks/3ss_7_zmjez-_.js","/_next/static/chunks/1ntn7efqc-iiw.js","/_next/static/chunks/19rivyb3ahph9.js","/_next/static/chunks/035xa7dcsshqz.js","/_next/static/chunks/0kjl5cgc-m731.js","/_next/static/chunks/3vhbmpumilg-x.js","/_next/static/chunks/1rpeln0a8ianr.js"],"DashboardPage"]
3:I[897367,["/_next/static/chunks/3ss_7_zmjez-_.js","/_next/static/chunks/1ntn7efqc-iiw.js"],"OutletBoundary"]
4:"$Sreact.suspense"
0:{"rsc":["$","$1","c",{"children":[["$","main",null,{"className":"min-h-screen bg-gray-100 p-2","children":["$","$L2",null,{}]}],[["$","script","script-0",{"src":"/_next/static/chunks/035xa7dcsshqz.js","async":true}],["$","script","script-1",{"src":"/_next/static/chunks/0kjl5cgc-m731.js","async":true}],["$","script","script-2",{"src":"/_next/static/chunks/3vhbmpumilg-x.js","async":true}],["$","script","script-3",{"src":"/_next/static/chunks/1rpeln0a8ianr.js","async":true}]],["$","$L3",null,{"children":["$","$4",null,{"name":"Next.MetadataOutlet","children":"$@5"}]}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"tY43c_ob_NXNTf-d4Hi-_"}
5:null
