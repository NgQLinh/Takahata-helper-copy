module.exports=[628101,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_workspace_admin_index_page_actions_0emffux.js.map