module.exports=[866853,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_workspace_admin_machines_page_actions_0g7qpy6.js.map